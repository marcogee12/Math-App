﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Math_App
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void calculateClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if ((bool)Addition.IsChecked)
                {
                    AddValues();
                }
                else if ((bool)Subtraction.IsChecked)
                {
                    SubtractValues();
                }
                else if ((bool)Multiplication.IsChecked)
                {
                    MultiplyValues();
                }
                else if ((bool)Division.IsChecked)
                {
                    DivideValues();
                }
                else
                {
                    throw new InvalidOperationException("You did not select an operator!");
                }
            }
            catch (FormatException)
            {
                Result.Text = "Expression is in incorrect format!";
            }
            catch (OverflowException oEx)
            {
                Result.Text = oEx.Message;
            }
            catch (InvalidOperationException iEx)
            {
                Result.Text = iEx.Message;
            }
            catch (DivideByZeroException dbzEx)
            {
                Result.Text = dbzEx.Message;
            }
            catch (Exception Ex)
            {
                Result.Text = Ex.Message;
            }
        }

            private void AddValues()
            {
                double LeftI = Convert.ToDouble(Left_Input.Text);
                double RightI = Convert.ToDouble(Right_Input.Text);
                double outcome = 0;
                outcome = LeftI + RightI;
                Expression_Display.Text = $"{LeftI} + {RightI} =";
                Result.Text = outcome.ToString();
            }

            private void SubtractValues()
            {
            double LeftI = Convert.ToDouble(Left_Input.Text);
            double RightI = Convert.ToDouble(Right_Input.Text);
            double outcome = 0;
            outcome = LeftI - RightI;
            Expression_Display.Text = $"{LeftI} - {RightI} =";
            Result.Text = outcome.ToString();
            }

            private void MultiplyValues()
            {
            double LeftI = Convert.ToDouble(Left_Input.Text);
            double RightI = Convert.ToDouble(Right_Input.Text);
            double outcome = 0;
            outcome = LeftI * RightI;
            Expression_Display.Text = $"{LeftI} x {RightI} =";
            Result.Text = outcome.ToString();
             }
        private void DivideValues()
        {
            decimal LeftI = Convert.ToDecimal(Left_Input.Text);
            decimal RightI = Convert.ToDecimal(Right_Input.Text);
            decimal outcome = 0;
            outcome = LeftI / RightI;
            Expression_Display.Text = $"{LeftI} / {RightI} =";
            Result.Text = outcome.ToString();
        }
    }
}
